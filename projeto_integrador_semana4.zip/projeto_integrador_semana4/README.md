# Projeto Integrador — Portal de Tecnologia (Semana 4)

Projeto escolar com HTML/PHP, CSS e JavaScript, incluindo formulário de mensagens processado com PHP.

## Executar no XAMPP
1. Copie esta pasta para `C:\xampp\htdocs`.
2. Inicie o Apache no XAMPP Control Panel.
3. Abra `http://localhost/projeto_integrador_semana4/`.

## Formulário
O formulário envia Nome, E-mail, Assunto e Mensagem por POST. O PHP verifica campos obrigatórios e valida o formato do e-mail. Os dados apresentados são tratados com `htmlspecialchars()` para evitar interpretação de conteúdo HTML.

## Commit sugerido
`git add index.php style.css script.js README.md && git commit -m "Adiciona formulário PHP com validação"`
