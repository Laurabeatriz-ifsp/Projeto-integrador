const dicas = [
    "Use senhas fortes e diferentes para cada conta importante.",
    "Não abra links suspeitos enviados por desconhecidos.",
    "Mantenha seus programas e dispositivos atualizados."
];
const botaoDica = document.querySelector("#botaoDica");
const textoDica = document.querySelector("#textoDica");
let indiceDica = 0;

botaoDica.addEventListener("click", () => {
    indiceDica = (indiceDica + 1) % dicas.length;
    textoDica.textContent = dicas[indiceDica];
});
