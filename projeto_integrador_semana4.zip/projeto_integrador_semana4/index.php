<?php
$nomeProjeto = "Portal de Tecnologia";
$ano = date("Y");
$dicas = [
    "Use senhas fortes e diferentes para cada conta importante.",
    "Não abra links suspeitos enviados por desconhecidos.",
    "Mantenha seus programas e dispositivos atualizados."
];

$enviado = ($_SERVER["REQUEST_METHOD"] === "POST");
$nome = $email = $assunto = $mensagem = "";
$erros = [];

if ($enviado) {
    $nome = trim($_POST["nome"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $assunto = trim($_POST["assunto"] ?? "");
    $mensagem = trim($_POST["mensagem"] ?? "");

    if ($nome === "" || $email === "" || $assunto === "" || $mensagem === "") {
        $erros[] = "Preencha todos os campos obrigatórios.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erros[] = "Digite um e-mail válido.";
    }
}
function seguro($valor) { return htmlspecialchars($valor, ENT_QUOTES, "UTF-8"); }
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= seguro($nomeProjeto) ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header id="topo">
    <div class="container">
        <h1><?= seguro($nomeProjeto) ?></h1>
        <p>Descubra o mundo da informática e da inovação.</p>
    </div>
</header>
<nav aria-label="Navegação principal">
    <a href="#sobre">Sobre</a><a href="#dicas">Dicas</a><a href="#contato">Contato</a>
</nav>
<main class="container">
    <section id="sobre" class="cartao">
        <h2>Sobre o projeto</h2>
        <p>Este portal compartilha informações, curiosidades e dicas sobre tecnologia e segurança digital.</p>
        <p>Projeto desenvolvido em <?= seguro($ano) ?>.</p>
    </section>
    <section id="dicas" class="cartao">
        <h2>Dicas de segurança digital</h2>
        <p id="textoDica"><?= seguro($dicas[0]) ?></p>
        <button type="button" id="botaoDica">Mostrar outra dica</button>
    </section>
    <section id="contato" class="cartao">
        <h2>Envie sua mensagem</h2>
        <p>Preencha o formulário para enviar uma sugestão ou dúvida sobre tecnologia.</p>
        <?php if ($enviado): ?>
            <?php if (!empty($erros)): ?>
                <div class="resultado erro" role="alert">
                    <h3>Não foi possível enviar</h3>
                    <?php foreach ($erros as $erro): ?><p><?= seguro($erro) ?></p><?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="resultado sucesso" role="status">
                    <h3>Mensagem recebida!</h3>
                    <p>Obrigada, <?= seguro($nome) ?>. Confira os dados enviados:</p>
                    <ul>
                        <li><strong>E-mail:</strong> <?= seguro($email) ?></li>
                        <li><strong>Assunto:</strong> <?= seguro($assunto) ?></li>
                        <li><strong>Mensagem:</strong> <?= seguro($mensagem) ?></li>
                    </ul>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        <form method="POST" action="#contato">
            <label for="nome">Nome *</label>
            <input type="text" id="nome" name="nome" required value="<?= seguro($nome) ?>">
            <label for="email">E-mail *</label>
            <input type="email" id="email" name="email" required value="<?= seguro($email) ?>">
            <label for="assunto">Assunto *</label>
            <input type="text" id="assunto" name="assunto" required value="<?= seguro($assunto) ?>">
            <label for="mensagem">Mensagem *</label>
            <textarea id="mensagem" name="mensagem" rows="4" required><?= seguro($mensagem) ?></textarea>
            <button type="submit">Enviar mensagem</button>
            <small>* Campos obrigatórios.</small>
        </form>
    </section>
</main>
<footer><p>&copy; <?= seguro($ano) ?> <?= seguro($nomeProjeto) ?>.</p></footer>
<script src="script.js"></script>
</body>
</html>
