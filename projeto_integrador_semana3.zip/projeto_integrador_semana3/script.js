const nomeDoProjeto = "Portal de Tecnologia";
const nomeDoEstudante = "Laura";
console.log("Projeto: " + nomeDoProjeto);
console.log("Estudante: " + nomeDoEstudante);

const botaoDica = document.querySelector("#botao-dica");
const textoDica = document.querySelector("#texto-dica");
const dicas = [
  "Use senhas fortes e diferentes para cada conta importante.",
  "Evite clicar em links suspeitos recebidos por mensagem ou e-mail.",
  "Mantenha seus programas e dispositivos atualizados."
];
let indiceDica = 0;

botaoDica.addEventListener("click", function () {
  textoDica.textContent = dicas[indiceDica];
  indiceDica = (indiceDica + 1) % dicas.length;
  botaoDica.textContent = "Mostrar outra dica";
});
