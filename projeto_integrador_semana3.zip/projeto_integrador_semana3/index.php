<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Portal de Tecnologia</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header id="topo">
    <div class="container">
      <p class="marca">TECH<span>+</span></p>
      <h1>Portal de Tecnologia</h1>
      <p class="subtitulo">Explore ideias, ferramentas e curiosidades do mundo digital.</p>
      <nav aria-label="Navegação principal">
        <a href="#sobre">Sobre</a><a href="#explore">Explore</a><a href="#dica">Dica do dia</a>
      </nav>
    </div>
  </header>
  <main class="container">
    <section id="sobre" class="bloco">
      <h2>Sobre o projeto</h2>
      <p>Este portal reúne informações introdutórias sobre tecnologia e informática. A proposta é aprender um pouco mais sobre o universo digital de maneira simples e acessível.</p>
      <p class="info-php">Projeto: <?php $nomeProjeto = "Portal de Tecnologia"; echo $nomeProjeto; ?> | Desenvolvido em <?php $ano = date("Y"); echo $ano; ?>.</p>
    </section>
    <section id="explore" class="bloco">
      <h2>Explore a tecnologia</h2>
      <p>Conheça alguns temas que fazem parte do nosso dia a dia:</p>
      <div class="cartoes">
        <article class="cartao"><h3>Programação</h3><p>É o processo de criar instruções para que computadores e outros dispositivos executem tarefas.</p></article>
        <article class="cartao"><h3>Internet</h3><p>Uma rede mundial que conecta dispositivos e permite compartilhar informações.</p></article>
        <article class="cartao"><h3>Hardware</h3><p>São as partes físicas de um computador, como teclado, memória e monitor.</p></article>
      </div>
    </section>
    <section id="dica" class="bloco interativo">
      <h2>Dica de tecnologia</h2>
      <p id="texto-dica">Clique no botão para descobrir uma dica simples de segurança digital.</p>
      <button id="botao-dica" type="button">Mostrar dica</button>
    </section>
  </main>
  <footer><p>Projeto Integrador • Semana 3</p></footer>
  <script src="script.js"></script>
</body>
</html>
