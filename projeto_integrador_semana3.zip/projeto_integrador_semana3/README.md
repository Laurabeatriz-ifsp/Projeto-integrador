# Projeto Integrador — Portal de Tecnologia

Projeto criado e ampliado ao longo das Semanas 1, 2 e 3.

## Arquivos
- `index.php`: estrutura da página e informação gerada pelo PHP.
- `style.css`: estilos visuais.
- `script.js`: dicas interativas usando DOM.

## Executar no XAMPP
1. Copie a pasta `projeto_integrador_semana3` para `C:\xampp\htdocs` e renomeie-a para `projeto_integrador` (ou use o nome atual no endereço).
2. Inicie o Apache no painel do XAMPP.
3. Acesse `http://localhost/projeto_integrador_semana3/` (ou o nome escolhido).

## Git: exemplo de três commits
```bash
git init
git add index.php style.css script.js README.md
git commit -m "Cria estrutura inicial do portal"
git add style.css
 git commit -m "Organiza estilos da página"
git add script.js index.php
git commit -m "Adiciona dicas interativas e informação PHP"
```

Para publicar: crie um repositório vazio no GitHub e siga as instruções para conectar o repositório local e fazer o `git push`.
